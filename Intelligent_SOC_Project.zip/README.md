# Intelligent SOC Threat Detection System

## Project overview
An educational Security Operations Center (SOC) dashboard that reads CSV security events, applies transparent detection rules, classifies alerts, and recommends human-reviewed response steps.

## Requirements
- Python 3.10 or newer
- Internet access only to install packages the first time
- Windows, macOS, or Linux

## Run on Windows
1. Extract this ZIP file.
2. Open the extracted folder.
3. Open Command Prompt in this folder.
4. Create a virtual environment (recommended):
   `py -m venv .venv`
5. Activate it:
   `.venv\Scripts\activate`
6. Install packages:
   `python -m pip install -r requirements.txt`
7. Start the dashboard:
   `python -m streamlit run app.py`
8. Open the local URL shown in the terminal (usually http://localhost:8501).

If `py` does not work, try `python` instead.

## Try the demonstration
The dashboard loads sample events automatically. It should flag repeated failed logins from one source and sample security events. Use the sidebar to upload `sample_logs.csv`.

## CSV format
Required columns:
- `timestamp`
- `source_ip`
- `username`
- `event_type`
- `status`

Example event types: `login`, `malware_detected`, `unauthorized_access`, `privilege_escalation`.
Example statuses: `success`, `failed`, `alert`.

## Detection rules
- 3–4 failed login events from one IP: medium-severity alert.
- 5 or more failed login events from one IP: high-severity alert.
- Malware and privilege-escalation event types: high-severity alert.
- Unauthorized-access and suspicious-process event types: medium-severity alert.

These thresholds are demonstration choices, not universal security standards.

## Safety and limitations
- Use only logs you are authorized to access.
- This is a prototype, not a production security product.
- It does not block IPs, quarantine files, or perform live scanning.
- Detection is rule-based; no trained machine-learning model is included in this starter version.
- IP addresses in the sample file are documentation/example ranges, not real attacker attribution.
- False positives and false negatives are possible. Human review is required.

## Suggested future improvements
1. Parse Windows Event Logs or Wazuh alerts.
2. Add a tested anomaly-detection model using a documented dataset.
3. Add time-window-based correlation and alert deduplication.
4. Add authentication and audit trails if multiple users will use it.
5. Test against labeled benign/malicious events and report precision, recall, and false-positive rate.
